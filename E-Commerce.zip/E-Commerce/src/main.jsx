import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import "./global/custom.css";

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
